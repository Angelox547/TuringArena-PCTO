Triangoli

Per definire un triangolo si possono usare vari metodi, traminte gli angoli o i lati. In questo esercizzio si utilizer� il metodo conoscendo i tre lati e definendo il tipo di triangolo che si puo ottenere

Luca viene chiamato alla lavagna dal professore che gli mostra 3 rametti raccolti nel cortile della scuola disposti uno difianco all'altro. l'insegnate chiede a Luca che triangolo si puo ottere se isoscele, scaleno, equilattere o nessuno soltanto guardando la lungheza dei rametti.

scrivi una funzione f
che in base ai tre dati posseduto ne ricavi il tipo di triangolo e verifichi che possano anche non formare nessun tipo di triangolo.
f(a,b,c) deve restituire un intero che coriscondera ai lati in comune:
- f(a,b,c)=0 se � scaleno
- f(a,b,c)=2 se � isoscele
- f(a,b,c)=3 se � equilatero
- f(a,b,c)=1 se non pu� essere un triangolo